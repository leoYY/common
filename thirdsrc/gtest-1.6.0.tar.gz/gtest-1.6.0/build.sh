#!/bin/bash

./configure

make clean 
make

cd src 
ar -rv libgtest_main.a gtest_main.o
ar -rv libgtest.a gtest-all.o
cd ..

mkdir -p lib/
cp src/libgtest.a lib/
cp src/libgtest_main.a lib/


